const premiumUsers = [
  '123456789' 
];

module.exports = premiumUsers;