module.exports = {
  BOT_TOKEN: "7246824363:AAEroOWUB2480tItxpJ8phK-sXhkOGmhOm4",
  OWNER_ID: ["5941299656"],
};