const supervipUsers = [
  "6044347011",
  "7943237510"
];

module.exports = supervipUsers;